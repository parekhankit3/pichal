[![Build Status](http://ec2-54-241-165-36.us-west-1.compute.amazonaws.com/buildStatus/icon?job=pi-challenge)](http://ec2-54-241-165-36.us-west-1.compute.amazonaws.com/job/pi-challenge/)

# pi-challenge
Use a Jenkins pipeline job to run a script that computes the value of pi.
